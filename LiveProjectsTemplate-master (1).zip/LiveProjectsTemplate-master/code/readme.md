# code

This folder holds all your source code for your product.

If your product has multiple services or apps, it's best that each one gets their own subproject. 

Make sure you clone the [subproject template](https://github.com/CMDT/LiveProjectsSubProject), check it in, and then link to it from this parent project.