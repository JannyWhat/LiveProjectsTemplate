# Worklogs

Horribly useful. Use a worklog while you are investigating something, or trying to make something work.

Use VisualStudio Code [Insert Date String](https://marketplace.visualstudio.com/items?itemName=jsynowiec.vscode-insertdatestring) to timestamp your entries.

You can go back to them when you forget a crucial step :-)

Add files  with a name like:

```
worklog_<yourname>_<ddmmyy>.md
```

