# Code

Folder to add code snippets which will be useful to make a decision on implementation.   

Check-in and link, from your discussion / investigation boards on Trello.

