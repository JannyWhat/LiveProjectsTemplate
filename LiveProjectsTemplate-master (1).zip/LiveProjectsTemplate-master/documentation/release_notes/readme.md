## release_notes

Each release needs a file, named:

```
release_notes_v<major_version>_<minor_version>.md
```

In it, list:

- major bug fixes
- features implemented

