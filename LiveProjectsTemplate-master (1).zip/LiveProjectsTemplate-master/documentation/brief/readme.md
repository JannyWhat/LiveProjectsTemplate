# Brief

Put your client brief into this folder. Refer to it from your Trello boards