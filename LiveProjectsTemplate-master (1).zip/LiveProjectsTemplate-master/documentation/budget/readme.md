## Budget
This folder contains the effort_commitment.xlsx tool. Use this to find your team's expected effort expenditure (in developer hours) over the whole project. More information [here](../your_project.md)

Upload to [Google Sheets](https://www.google.co.uk/sheets/about/), to work on it as a group, simultaneously - but don't forget to download it again, and **check it in**!