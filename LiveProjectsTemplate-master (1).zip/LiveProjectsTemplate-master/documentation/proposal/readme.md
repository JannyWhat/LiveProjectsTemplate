# Proposal

Your proposal is produced as part of your design and estimate process, and is proof that youtr client has accepted your desig, and is ready to move on to construction.

Put your proposal to the client in this folder.